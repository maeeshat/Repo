create database Healthcare_Project;
use Healthcare_Project;
show tables;

-- now we want to import dataset
-- Confirm the number of rows
select * from healthcare_dataset ;

select count(*) from healthcare_dataset;

-- Creating a duplicate table
create  table Healthcare as (select * from healthcare_dataset);

describe healthcare;

-- checking for duplicates
select Name,Age,Gender,`Blood Type`,`Medical Condition`,`Date of Admission`,
Doctor,Hospital,`Insurance Provider`,`Billing Amount`,`Room Number`,
`Admission Type`,`Discharge Date`,Medication,`Test Results`,
count(*) as duplicates
from healthcare
group by
Name,Age,Gender,`Blood Type`,`Medical Condition`,`Date of Admission`,
Doctor,Hospital,`Insurance Provider`,`Billing Amount`,`Room Number`,`Admission Type`,
`Discharge Date`,Medication,`Test Results`
having duplicates>1;

-- checking for spelling errors
select distinct Name from healthcare;
select distinct Age from healthcare;
select distinct Gender from healthcare;
select distinct `Blood Type` from healthcare;
select distinct `Medical Condition` from healthcare;
select distinct `Date of Admission` from healthcare;
select distinct Doctor from healthcare;
select distinct Hospital from healthcare;
select distinct `Insurance Provider` from healthcare;
select distinct `Billing Amount` from healthcare;
select distinct `Room Number` from healthcare;
select distinct `Admission Type` from healthcare;
select distinct `Discharge Date`from healthcare;
select distinct Medication from healthcare;
select distinct `Test Results`from healthcare;

-- checking for empty space
select * from healthcare where Name ='';
select * from healthcare where Age ='';
select * from healthcare where Gender ='';
select * from healthcare where `Blood Type` ='';
select * from healthcare where `Medical Condition`='';
select * from healthcare where `Date of Admission`='';
select * from healthcare where Doctor ='';
select * from healthcare where Hospital ='';
select * from healthcare where `Insurance Provider` ='';
select * from healthcare where `Billing Amount`='';
select * from healthcare where `Room Number` = '';
select * from healthcare where `Admission Type` ='';
select * from healthcare where `Discharge Date` ='';
select * from healthcare where Medication='';
select * from healthcare where `Test Results` = '';

select min(age), max(age) from healthcare;
alter table healthcare drop column Hospital;
select * from healthcare;


alter table healthcare add column Age_Range text after Age;

set sql_safe_updates = 0;
start transaction;
update healthcare set Age_Range = case
                               when Age between 18 and 28 then '18-28'
                               when Age between 29 and 39 then '29 -39' 
                               when Age between 40 and 50 then '40-50'
                               when Age between 51 and 61 then '51-61'
                               when Age between 62 and 72 then '62-72'
                               else '72+'
                               end;
                               
select * from healthcare;

alter table healthcare modify column `Billing Amount`int;
alter table healthcare modify column `Date of Admission` date;
alter table healthcare modify column `Discharge Date` date;

alter table healthcare
add column Patient_ID int primary key auto_increment first;

describe healthcare;

select
    YEAR(`Date of Admission`) as Admission_Year,
    COUNT(*) as Total_Admissions
FROM healthcare
GROUP BY YEAR(`Date of Admission`)
ORDER BY Admission_Year;

select
    YEAR(`Date of Admission`) as Admission_Year,
    MONTH(`Date of Admission`) as Admission_Month,
    COUNT(*) as Total_Admissions
FROM healthcare
GROUP BY 
    YEAR(`Date of Admission`),
    MONTH(`Date of Admission`)
ORDER BY 
    Admission_Year,
    Admission_Month;
    
    SELECT 
    Gender,
    COUNT(*) AS Total_Patients
FROM healthcare
GROUP BY Gender
ORDER BY Total_Patients DESC;

SELECT 
    Age,
    COUNT(*) AS Total_Patients
FROM healthcare
GROUP BY Age
ORDER BY Age;
							
SELECT 
    Age_Range,
    COUNT(*) AS Total_Patients
FROM healthcare
GROUP BY Age_Range
ORDER BY Age_Range;

SELECT 
    `Medical Condition`,
    COUNT(*) AS Total_Patients
FROM healthcare
GROUP BY `Medical Condition`
ORDER BY Total_Patients DESC;

SELECT
    `Medical Condition`,
    COUNT(*) AS Total_Patients,
    ROUND(
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM healthcare),
        2
    ) AS Percentage
FROM healthcare
GROUP BY `Medical Condition`
ORDER BY Total_Patients DESC;
commit;
select * from healthcare;
select count(*) from 
							
			


